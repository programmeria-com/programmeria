import React from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter, Switch, Route} from "react-router-dom";// BrowserRouter as Router, NavLink

// import Aroute from './q-ui-react/Aroute';
import {setClass, getAttr} from './utils/Q';
import NavMain from './containers/NavMain';
import AsideMain from './containers/AsideMain';
import MainContent from './containers/MainContent';

import Flex from './q-ui-react/Flex';
import Btn from './q-react-bootstrap/Btn';

// import Editor from './monaco-react';

// PAGES:
import Icons from './pages/Icons';
import CssUtils from './pages/CssUtils';
import NotFound from './pages/NotFound';

// DEVS:
// import ImportEsm from './dev/ImportEsm';
// import Lodash from './dev/LoadLib';
// import loadable from '@loadable/component';

// FOR SET admin page
setClass(document.body, 'adm text-sm ovyscroll');

export default class MainApp extends React.Component{
	constructor(props){
		super(props);
		this.state = {
			theme: 'dark',
			openNav: false,
		}
	}
  // const [openNav, setOpenNav] = React.useState(false);

	componentDidMount(){
	// React.useEffect(() => {
		// FOR SET admin page
		// setClass(document.body, 'adm text-sm ovyscroll');
		console.log('%cProgrammeria\n','color:#666;font-family:sans-serif;letter-spacing:2px;font-size:26px;font-weight:700;text-shadow:1px 1px 0 #A0E7FE,2px 2px 1px rgba(0,0,0,.3)');
		console.log('%cDevelopment by: https://programmeria.com','font-size:15px');
	// }, []);
		// console.log(Lod);
		
		// let docWidth = document.documentElement.offsetWidth;
		// [].forEach.call(
			// document.querySelectorAll('*'),
			// function(el){
				// if(el.offsetWidth > docWidth){
					// console.log(el);
				// }
			// }
		// );
	}

	componentDidUpdate(prevProps){
    const {location} = this.props;
		if(location.pathname !== prevProps.location.pathname){ //  && !location.pathname.includes('/detail/')
      window.scrollTo(0,0);

      // DEV to set previous url FOR Not Found page
      // this.setState({backUrl: prevProps.location.pathname});
    }

	// FOR close dropdown-menu with dropdown-item react-router NavLink / Link component
		let btn = document.activeElement;
		if(getAttr(btn, 'aria-expanded') === 'true'){ // hasClass(btn, "ddRoute") ||
			btn.click();
			btn.blur();
		}
	}

	render(){
		const {location} = this.props;// history
		const {theme, openNav, } = this.state;
		
		return (
			<React.Fragment>
				<NavMain theme={theme} openNav={openNav} setOpenNav={() => this.setState({openNav: !openNav})} />

				<Flex wrap dir="row">{/* wrapper | row no-gutters app-box | row mx-auto */}
					<AsideMain location={location} />

					<MainContent>
						<Switch>
							<Route exact path="/">
								<div>
									Home
								</div>
							</Route>
							
							<Route path="/icons">
								<Icons />
							</Route>
							
							<Route path="/css-utilities">
								<CssUtils />
							</Route>
							
							<Route>
								<NotFound />
							</Route>
						</Switch>
						
					</MainContent>
				</Flex>
			</React.Fragment>
		);
	}
}

// basename="/admin"
const App = () =>
	<BrowserRouter>
		<Route component={MainApp} />
	</BrowserRouter>

ReactDOM.render(<App />, root);

// if(document.getElementById('root')){
  // ReactDOM.render(<Example />, document.getElementById('root'));
// }
