import React from 'react';
// import Btn from '../../components/reactstrap/Btn';

export default class ComponentName extends React.Component{
  constructor(props){
    super(props);
    this.state = {

    };
		
  }

  componentDidMount(){
		console.log('%ccomponentDidMount in ComponentName','color:yellow;');
  }

  render(){

    return (
      <React.Fragment>
				
      </React.Fragment>
    );
  }
}

/*

*/
