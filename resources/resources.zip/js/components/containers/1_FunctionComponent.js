import React from 'react';
// import Btn from '../../components/q-ui-bootstrap/Btn';

export default function ComponentName(){
  // const [data, setData] = React.useState();
	
	React.useEffect(() => {
		console.log('%cuseEffect in ComponentName','color:yellow;');
	}, []);

	return (
		<React.Fragment>
			
		</React.Fragment>
	);
}

/*

*/
