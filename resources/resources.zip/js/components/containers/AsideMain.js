import React from 'react';
import UctrlDropdown from '../q-react-bootstrap/UctrlDropdown';// Btn
import DropdownToggle from '../q-react-bootstrap/DropdownToggle';
import DropdownMenu from '../q-react-bootstrap/DropdownMenu';
import DropdownItem from '../q-react-bootstrap/DropdownItem';
import Aroute from '../q-ui-react/Aroute';
import Img from '../q-ui-react/Img';
import Loops from '../q-ui-react/Loops';

// <Aroute nav to="/icons" className="q q-icons q-fw" tip="Icons">Icons</Aroute>
const getObjItems = (obj, key) => obj.map(v => v[key]);

const DOCS_LINK = [
	{to:"/icons", i:"icons", tip:"Icons"},
	{to:"/css-utilities", i:"css", tip:"CSS Utilities"}
];

const DOCS_URL = getObjItems(DOCS_LINK, 'to');

export default function AsideMain({location}){
  // const [data, setData] = React.useState();
	
	// React.useEffect(() => {
		// console.log('%cuseEffect in AsideMain','color:yellow');
	// }, []);

	return (
		<aside className="sidebar">{/* col-md-2 bg-light  */}
			<UctrlDropdown direction="right" className="dd-ava">
				<DropdownToggle kind="light" className="d-flex align-items-center w-100 text-left rounded-0">
					{/* frameClass="mr-2" */}
					<Img frame fluid className="mr-2" w={30} h={30} alt="User" src="/img/avatar_man.png"/> Username
				</DropdownToggle>
				
				<DropdownMenu className="w-100 ml-0 rounded-0">
					<DropdownItem>Settings</DropdownItem>
				</DropdownMenu>
			</UctrlDropdown>

			<div className="q-scroll sidebar-sticky">
				<nav className="nav flex-column">
					<Aroute nav className="q q-home q-fw" to="/admin" tip="Dashboard">Dashboard</Aroute>
					<details className="q-detail">
						<summary className="nav-link q q-cogs q-fw" title="Settings">Settings</summary>
						<div role="group" className="bg-rgba-1">
							<Aroute nav 
								className="q q-cog q-fw"
								to="admin/settings/general"
								tip="General"
							>
								General
							</Aroute>
							<Aroute nav className="q q-lock q-fw" to="/privacy" tip="Privacy">Privacy</Aroute>
							{/*<Aroute nav 
								className="q q-plus q-fw"
								to="admin/create-group"
								tip="Buat Group"
							>
								Buat Group
							</Aroute>*/}
						</div>
					</details>
					<details className="q-detail">
						<summary className="nav-link q q-cogs q-fw" title="Settings Pages">Pages</summary>
						<div role="group" className="bg-rgba-1">
							<a className="nav-link q q-cog q-fw" href="admin/pages/home" title="Setting Home">
								Home
								<b className="badge badge-light ml-auto cpoin q q-star appInfo"
									// data-toggle="modal"
								/>
							</a>
						</div>
					</details>
					<details className="q-detail">
						<summary className="nav-link q q-user q-fw" title="User">User</summary>
						<div role="group" className="bg-rgba-1">
							<a className="nav-link q q-users q-fw" href="admin/users" title="All User">All Users</a>
							<a className="nav-link q q-plus q-fw" href="admin/create-user" title="Add user">Add user</a>
						</div>
					</details>
					{/*<a className="nav-link q q-users q-fw" href="admin/konsumen" title="Konsumen">Konsumen</a>*/}
					<a className="nav-link q q-article q-fw" href="admin/article" title="Article">Article</a>
					<a className="nav-link q q-envelope q-fw" href="admin/inbox" title="Inbox">Inbox</a>
					
					<details className="q-detail" open={DOCS_URL.includes(location.pathname)}>
						<summary className="nav-link q q-book q-fw" title="Documentation">Documentation</summary>
						<div role="group" className="bg-rgba-1">
							<Loops data={DOCS_LINK}>
								{(v, i) => <Aroute nav to={v.to} className={"q q-fw q-" + v.i} tip={v.tip}>{v.tip}</Aroute>}
							</Loops>
						</div>
					</details>
				</nav>
			</div>
			
			<footer className="p-1 border-top text-center bg-white">
				{/* eslint-disable-next-line */}
				<a href="https://programmeria.com" className="text-muted" target="_blank">
					©<span>programmeria.com</span>
				</a>
				
				{/* eslint-disable-next-line */}
				<div className="mt-1 ml-2-next">
					<Loops 
						data={[
							{url:"https://facebook", name:"facebook", c:"text-primary"},
							{url:"https://twitter", name:"twitter", c:"text-info"},
							{url:"https://www.instagram.com/programmeria/", name:"instagram", c:"text-purple"},
							{url:"https://www.youtube.com/channel/UCNGyKniaCiO3mZXGcLSnhOw", name:"youtube", c:"text-danger"},
							{url:"https://github.com/programmeria-com", name:"github", c:"text-dark"}
						]}
					>
						{(v, i) => (
							<a href={v.url} 
								className={"q q-" + v.name + " " + v.c} 
								target="_blank"
								rel="noopener noreferrer" 
								aria-label={v.name} 
							/>
						)}
					</Loops>
				</div>
				
			</footer>
		</aside>
	);
}


