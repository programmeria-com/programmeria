import React from 'react';
import Flex from '../q-ui-react/Flex';
import Btn from '../q-react-bootstrap/Btn';

export default function MainContent({children}){
  // const [data, setData] = React.useState();
	
	// React.useEffect(() => {
		// console.log('%cuseEffect in MainContent','color:yellow;');
	// }, []);

	return (
		<Flex As="main" dir="column" wrap className="ml-auto appbox">
			<Flex dir="row" nowrap justify="between" align="center" className="py-2 px-3 border-bottom bg-white position-sticky top-40 zi-1001">
				<h6 className="mb-0">Title Page</h6>
				<div className="ml-1-next">
					<Btn outline size="sm" qtip="B" tip="User Guide">Guide</Btn>
				</div>
			</Flex>
			
			{children}
		</Flex>
	);
}

/* <nav className="navbar navbar-expand-lg navbar-light bg-light position-sticky top-40 zi-1001">
			<Flex nowrap align="center" className="flex-md-nowrap w-100 py-1 px-2 border-bottom bg-white position-sticky top-40 zi-1001">
				<h6 className="mb-0">Title Page</h6>
				<div className="ml-1-next">
					<Btn outline size="sm" qtip="B" tip="User Guide">Guide</Btn>
				</div>
			</Flex>
*/
