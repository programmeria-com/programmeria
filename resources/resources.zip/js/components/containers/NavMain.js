import React from 'react';
import Navbar from '../q-react-bootstrap/Navbar';
import NavbarBrand from '../q-react-bootstrap/NavbarBrand';
import NavbarToggler from '../q-react-bootstrap/NavbarToggler';
// import Nav from '../q-react-bootstrap/Nav';
// import NavItem from '../q-react-bootstrap/NavItem';
// import NavLink from '../q-react-bootstrap/NavLink';
// import NavbarText from '../q-react-bootstrap/NavbarText';
import UctrlDropdown from '../q-react-bootstrap/UctrlDropdown';
import DropdownToggle from '../q-react-bootstrap/DropdownToggle';
import DropdownMenu from '../q-react-bootstrap/DropdownMenu';
import DropdownItem from '../q-react-bootstrap/DropdownItem';
import Collapse from '../q-react-bootstrap/Collapse';
import Btn from '../q-react-bootstrap/Btn';

import Flex from '../q-ui-react/Flex';
import Aroute from '../q-ui-react/Aroute';

import useStateCb from '../utils/useStateCb';
import {toggleClass} from '../utils/Q';// setClass

export default function NavMain({theme, openNav, setOpenNav}){
  // const [openAside, setOpenAside] = React.useState(true);
	const asideMin = localStorage.getItem('asideMin') === 'true' ? true:false;
  const [minAside, setMinAside] = useStateCb(asideMin, min => {
		toggleClass(document.body, 'aside-min', min);
		localStorage.setItem('asideMin', min);
  });
	
	// React.useEffect(() => {
		// console.log('%cuseEffect in ComponentName','color:yellow;');
	// }, []);
	
	const toggleAside = () => {
		setMinAside(!minAside);
	}

// <Flex align="center" className="app-brand">
	// <NavbarBrand href="/" className="mr-0 nav-link flex-grow-1 text-truncate text-white" title="Programmeria">Programmeria</NavbarBrand>
// </Flex>

	return (
		<Navbar dark kind="primary" expand="md" sticky="top" className="link-sm" id="navTopMain">
			<a href="https://programmeria.com"
				className={"app-brand p-2 text-truncate text-" + (theme === "dark" ? "light" : "dark")}
			>
				Programmeria
			</a>
			
			<NavbarToggler onClick={setOpenNav} />
			
			<Collapse isOpen={openNav} navbar>
				<div className="navbar-nav mr-auto">
					<Btn onClick={toggleAside} size="sm" kind="light" className={"q q-chev-" + (minAside ? 'right':'left')} tip={minAside ? 'Maximize':'Minimize'} qtip="R" />
					<Aroute nav exact to="/">Home</Aroute>
					
					
					<UctrlDropdown nav inNavbar>
						<DropdownToggle nav caret>Apps</DropdownToggle>
						<DropdownMenu right>
							<Aroute dropdown to="/package-manager">Package Manager</Aroute>
							<DropdownItem>App Builder</DropdownItem>
							<hr />
							<DropdownItem>More</DropdownItem>
						</DropdownMenu>
					</UctrlDropdown>
				</div>
			
				
			</Collapse>
		</Navbar>	
	);
}

/*
				<Nav className="mr-auto" navbar>
					<NavItem>
						<Btn onClick={toggleAside} size="sm" kind="light" className={"q q-chev-" + (minAside ? 'right':'left')} tip={minAside ? 'Maximize':'Minimize'} qtip="R" />
					</NavItem>
					<NavItem>
						<Aroute to="/admin-ui" nav>Admin UI</Aroute>
					</NavItem>
					
					<UctrlDropdown nav inNavbar>
						<DropdownToggle nav caret>Options</DropdownToggle>
						<DropdownMenu right>
							<DropdownItem>Option 1</DropdownItem>
							<DropdownItem>Option 2</DropdownItem>
							<hr />
							<DropdownItem>Reset</DropdownItem>
						</DropdownMenu>
					</UctrlDropdown>
				</Nav>

<NavbarText>Simple Text</NavbarText>
*/
