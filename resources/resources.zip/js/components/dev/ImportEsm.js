/** import native ES Modules
	@usage:
	ImportEsm('/storage/esm/tryModule.js', {
		onOk:(m, f) => {
			m.tryModule('OKEH')
			console.log(f)
		}
	})
*/

const ImportEsm = (file, {onOk = () => {}, onErr = () => {}}) => import(/*webpackIgnore:true*/ file).then(m => {
	onOk(m, file);
}).catch(e => {
	console.log(e);
	onErr(e, file);
});

export default ImportEsm;