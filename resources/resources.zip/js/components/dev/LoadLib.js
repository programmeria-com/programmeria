import React from 'react'
import loadable from '@loadable/component'

const Lod = loadable.lib(() => import('lodash'))

export default function Lodash({fn}){ // { date }
  return (
    <Lod fallback={<div>Loading...</div>}>
        {({ _ }) => _}
    </Lod>
  )
}

// {({ default: lodash }) => lodash[fn]}
