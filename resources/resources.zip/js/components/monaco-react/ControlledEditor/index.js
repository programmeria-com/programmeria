import { memo } from 'react';

import ControlledEditor from './ControlledEditor';

export default memo(ControlledEditor);
