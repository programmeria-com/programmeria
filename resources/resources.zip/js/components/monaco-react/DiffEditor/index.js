import { memo } from 'react';

import DiffEditor from './DiffEditor';

export default memo(DiffEditor);
