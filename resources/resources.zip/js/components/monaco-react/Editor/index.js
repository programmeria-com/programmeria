import { memo } from 'react';

import Editor from './Editor';

export default memo(Editor);
