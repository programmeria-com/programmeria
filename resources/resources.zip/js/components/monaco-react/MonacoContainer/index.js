import { memo } from 'react';

import MonacoContainer from './MonacoContainer';

export default memo(MonacoContainer);
