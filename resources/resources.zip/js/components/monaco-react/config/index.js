const config = {
  urls: {
		// https://cdn.jsdelivr.net/npm/monaco-editor@0.19.3/min/vs/loader.js
		// /storage/js/monaco-editor/min/vs/loader.js
    monacoLoader: '/storage/js/monaco-editor/min/vs/loader.js',
		// https://cdn.jsdelivr.net/npm/monaco-editor@0.19.3/min/vs
		// /storage/js/monaco-editor/min/vs
    monacoBase: '/storage/js/monaco-editor/min/vs',
  },
}

export default config;
