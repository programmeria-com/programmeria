import useMount from './useMount';
import useUpdate from './useUpdate';

export { useMount, useUpdate };
