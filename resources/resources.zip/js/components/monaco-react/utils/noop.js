const noop = _ => {};

export default noop;
