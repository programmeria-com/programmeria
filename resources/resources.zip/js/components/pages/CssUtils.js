import React from 'react';
import Flex from '../q-ui-react/Flex';
import Editor from '../monaco-react';// @monaco-editor/react

export default function CssUtils(){
  // const [data, setData] = React.useState();
	
	React.useEffect(() => {
		console.log('%cuseEffect in CssUtils','color:yellow');
	}, []);

// mx-min15
	return (
		
			<Editor 
				height="calc(100vh - 80px)" 
				className="ovhide" 
				language="javascript"
			/>
		
	);
}

/*

</React.Fragment>
*/
