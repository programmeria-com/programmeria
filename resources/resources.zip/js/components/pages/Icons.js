import React from 'react';
import axios from 'axios';
import Loops from '../q-ui-react/Loops';
import Btn from '../q-react-bootstrap/Btn';
// import Modal from '../q-react-bootstrap/Modal';
// import ModalHeader from '../q-react-bootstrap/ModalHeader';

import {Copy} from '../utils/clipboard/clipboardApi';

export default function Icons(){
  const [data, setData] = React.useState([]);
	// const [modal, setModal] = React.useState(false);
	// const [dataModal, setDataModal] = React.useState(null);
	
	React.useEffect(() => {
		// console.log('%cuseEffect in Icons','color:yellow');
		axios.get('storage/json/selection.json').then(res => {
			// console.log(res);
			if(res && res.status === 200){
				setData(res.data)
			}
		}).catch(e => console.log(e))
	}, []);
	
	// const onModal = () => setModal(!modal);
	const onCopy = (to, v) => {
		if(to === 'jsx'){
			Copy(`<i className="q ${v.properties.name}"></i>`, {
				onOk: txt => console.log('onOk', txt)
			})
		}
	}
	
	const goTop = () => 
		window.scrollTo({
      top:0,
      left:0,
      behavior:'smooth'
    });

	return (
		<div className="p-3">
			<div id="iconBox" className="row row-cols-2 row-cols-md-4">
				<Loops data={data.icons}>
					{(v, i) => 
						<div className="col mb-4">
							<div className="card">
								<i className={"card-img-top text-center py-3 q q-3 " + v.properties.name} />
								<div className="card-body p-2 border-top">
									<h5 className="card-title text-center">{v.properties.name}</h5>
									<input readOnly type="text" 
										onDoubleClick={e => e.target.select()} 
										// onCopy={} 
										className="form-control form-control-sm bg-white" 
										value={`<i className="q ${v.properties.name}"></i>`} 
									/>
								</div>
								<div className="card-footer p-2 txt-c">
									<Btn onClick={() => onCopy('jsx', v)} size="sm" kind="info">Copy JSX</Btn>{' '}
									<Btn size="sm" kind="info">Copy HTML</Btn>
								</div>
							</div>
						</div>
					}
				</Loops>
				
				<Btn onClick={goTop} As="div" size="sm" kind="primary" className="q q-arrow-up btnBackTop" qtip="L" tip="Back to top" />
			</div>
		</div>
	);
}

/*
      <Modal isOpen={modal} toggle={onModal}>
        <ModalHeader toggle={onModal} modalTitle="Modal title"></ModalHeader>
        <div className="modal-body">
					{dataModal ? 
						<React.Fragment>
							{dataModal.properties.name}
						</React.Fragment>
						: ''}
        </div>
        <div className="modal-footer">
          <Btn kind="primary" onClick={onModal}>Do Something</Btn>{' '}
          <Btn onClick={onModal}>Cancel</Btn>
        </div>
      </Modal>
*/
