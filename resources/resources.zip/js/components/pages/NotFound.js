import React from 'react';
import {useLocation} from 'react-router-dom';// Route,
// import { useLastLocation } from 'react-router-last-location';
import {Helmet, HelmetProvider} from 'react-helmet-async';// ../components_dev/react-helmet-async
import Flex from '../q-ui-react/Flex';
// import Aroute from '../components/q-ui-react/Aroute';

// const w = window;
// const origin = w.location.origin;
// const hLength = w.history.length;

export default function NotFound(){ // {backUrl}
  // const [backUrl, setBackUrl] = React.useState('/');
	let location = useLocation();
	// const lastLocation = useLastLocation();

	// React.useEffect(() => {
	// 	// console.log('%cuseEffect in NotFound','color:yellow;');
	// 	if(document.referrer.includes(origin) && hLength > 2){
	// 		console.log('document.referrer: ', document.referrer);
	// 		console.log(document.referrer.includes(origin));
	// 		console.log('hLength', hLength);
	// 		setBackUrl(location.pathname);
	// 	}
	// 	 return () => {
	//
	// 	 }
	// }, [backUrl]);

	// document.referrer.includes(origin)
	// console.log(document.referrer.includes(origin) && hLength > 2 && backUrl && backUrl !== '/');
	// console.log('location: ', location);

	// const onBack = e => {
	// 	if(document.referrer.includes(origin) && hLength > 2){
	// 		e.preventDefault();
	// 		console.log('onBack');
	// 		console.log('onBack hLength: ', hLength);
	// 		console.log('onBack w.history', w.history);
	// 		w.history.back();
	// 	}
	// }

	return (
		<HelmetProvider>
			<Helmet defer={false}>
				<title>Not Found - 404</title>
			</Helmet>

			<Flex dir="column" justify="center" align="center" className="container-fluid h-full-nav">
				<h3>
					No match for <code>{location.pathname}</code>
				</h3>
				{/*  && backUrl && backUrl !== '/' */}
				<a href="/" className="btn btn-primary">BACK TO HOME</a>
			</Flex>
		</HelmetProvider>
	);
}

// export default withLastLocation(NotFound);

/*
{(document.referrer.includes(origin) && hLength > 2) ?
	<Aroute
		// replace | backUrl
		to={`/`} btn="primary">
		BACK
	</Aroute>
	:
	<a href={origin} className="btn btn-primary">BACK TO HOME</a>
}

<Route
	path={location.pathname} // "*"
>
</Route>
							onClick={e => {
								let et = e.target;
								e.preventDefault();
								e.stopPropagation();
								et
							}}
*/
