import React from 'react';
import P from 'prop-types';
import Cls from 'classnames';
import { mapToCssModules, tagPropType } from './utils';
import Fade from './Fade';

function Alert({className, closeClass, closeAriaLabel, cssModule, as: As, kind, isOpen, toggle, children, transition, fade, innerRef, ...etc}){
  const setCls = mapToCssModules(Cls(
    'alert',
    `alert-${kind}`,
    { 'alert-dismissible': toggle },
		className
  ), cssModule);

  const closeCls = mapToCssModules(Cls('close', closeClass), cssModule);

  const alertTransition = {
    ...Fade.defaultProps,
    ...transition,
    baseClass: fade ? transition.baseClass : '',
    timeout: fade ? transition.timeout : 0
  };

  return (
    <Fade {...etc} {...alertTransition} as={As} className={setCls} in={isOpen} role="alert" innerRef={innerRef}>
      {toggle ?
        <button type="button" className={closeCls} aria-label={closeAriaLabel} onClick={toggle}>
          <span aria-hidden="true">&times;</span>
        </button>
        : null}
      {children}
    </Fade>
  );
}

Alert.propTypes = {
  children: P.node,
  className: P.string,
  closeClass: P.string,
  closeAriaLabel: P.string,
  cssModule: P.object,
  kind: P.string,
  fade: P.bool,
  isOpen: P.bool,
  toggle: P.func,
  as: tagPropType,
  // transition: P.shape(Fade.propTypes),
  innerRef: P.oneOfType([
    P.object,
    P.string,
    P.func
  ])
};
Alert.defaultProps = {
  kind: 'success',
  isOpen: true,
  as: 'div',
  closeAriaLabel: 'Close',
  fade: true,
  transition: {
    ...Fade.defaultProps,
    unmountOnExit: true
  }
};

export default Alert;
