import React from 'react';
// import PropTypes from 'prop-types';
// import classNames from 'classnames';
// import { mapToCssModules, tagPropType } from './utils';
import { mapToCssModules } from './utils';// tagPropType
import {Cx} from '../utils/Q';
import Fade from './Fade';

/* const propTypes = {
  children: PropTypes.node,
  className: PropTypes.string,
  closeClass: PropTypes.string,
  closeAriaLabel: PropTypes.string,
  cssModule: PropTypes.object,
  kind: PropTypes.string,
  fade: PropTypes.bool,
  isOpen: PropTypes.bool,
  toggle: PropTypes.func,
  As: tagPropType,
  transition: PropTypes.shape(Fade.propTypes),
  inRef: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.string,
    PropTypes.func,
  ]),
}; */

export default function Alert({className, closeClass, closeAriaLabel, cssModule, As, kind, isOpen, toggle, children, transition, fade, inRef, ...etc}){
  const setCx = mapToCssModules(Cx(
    'alert',
    `alert-${kind}`,
    { 'alert-dismissible': toggle },
		className
  ), cssModule);

  const closeCx = mapToCssModules(Cx('close', closeClass), cssModule);

  const alertTransition = {
    ...Fade.defaultProps,
    ...transition,
    baseClass: fade ? transition.baseClass : '',
    timeout: fade ? transition.timeout : 0
  };

  return (
    <Fade {...etc} {...alertTransition} As={As} className={setCx} in={isOpen} inRef={inRef} role="alert">
      {toggle && 
        <button type="button" className={closeCx} aria-label={closeAriaLabel} onClick={toggle}>
          <span aria-hidden="true">&times;</span>
        </button>
      }
			
      {children}
    </Fade>
  );
}

// Alert.propTypes = propTypes;
Alert.defaultProps = {
  kind: 'success',
  isOpen: true,
  As: 'div',
  closeAriaLabel: 'Close',
  fade: true,
  transition: {
    ...Fade.defaultProps,
    unmountOnExit: true
  }
};
