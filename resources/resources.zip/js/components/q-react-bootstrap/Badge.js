import React from 'react';
// import P from 'prop-types';
// import Cls from 'classnames';
import {Cx} from '../utils/Q';
import { mapToCssModules } from './utils';// tagPropType

export default function Badge({className, cssModule, kind, inRef, pill, As, ...etc}){
  const setCx = mapToCssModules(Cx(
    'badge',
    'badge-' + kind,
    pill ? 'badge-pill' : false,
		className
  ), cssModule);

  if(etc.href && As === 'span') As = 'a';

  return <As {...etc} ref={inRef} className={setCx} />;
};

Badge.defaultProps = {
	As: 'span',
  kind: 'secondary',
  pill: false
};
/* Badge.propTypes = {
  kind: P.string,
  pill: P.bool,
  // As: tagPropType,
  inRef: P.oneOfType([P.object, P.func, P.string]),
  children: P.node,
  className: P.string,
  cssModule: P.object
}; */

