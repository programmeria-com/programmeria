import React from 'react';
// import P from 'prop-types';
// import Cls from 'classnames';
import { mapToCssModules } from './utils';// tagPropType
import {Cx} from '../utils/Q';

// tipKind
export default function Btn({
	As, cssModule, active, 'aria-label':ariaLabel, block, className, close, kind, outline, size,
	inRef, type, role, tip, qtip, disabled, onClick, ...etc
}){
  // const Click = e => {
    // if(disabled){
      // e.preventDefault();
      // return;
    // }

    // if(onClick) onClick(e);
  // }

/* 	const setCls = mapToCssModules(Cls(
		{ close },
		close || 'btn',
		close || btnOutlineKind,
		size ? `btn-${size}` : false,
		block ? 'btn-block' : false,
		{ active, disabled: disabled },
		//ico ? `i q-${ico}` : false,
		qtip ? `tip tip${qtip}` : false,
		qtip && tipKind ? `tip-${tipKind}` : false,
		className
	), cssModule); */

	const closeAriaLabel = close ? 'Close' : null;
	const noChild = !etc.children || typeof etc.children === 'undefined' ? tip : null;
	const El = etc.href && As === 'button' ? As = 'a' : As;

	return (
		<El 
			{...etc} 
			ref={inRef} 
			className={
				mapToCssModules(Cx(
					{ close },
					close || 'btn',
					close || `btn${outline ? '-outline' : ''}-${kind}`,
					size ? `btn-${size}` : false,
					block ? 'btn-block' : false,
					{ active, disabled: disabled },
					//ico ? `i q-${ico}` : false,
					qtip ? `tip tip${qtip}` : false,
					// qtip && tipKind ? `tip-${tipKind}` : false,
					className
				), cssModule)
			} 
			type={As !== 'button' ? null : !type && As !== 'a' ? 'button' : type} 
			
			aria-label={ariaLabel || closeAriaLabel || noChild || (qtip && tip)} 
			// (As === 'a' || As === 'label' || As === 'span' || As === 'div')
			role={['a','label','span','div'].includes(As) && !type ? 'button' : undefined} 
			tabIndex={As === 'label' ? "0" : null} 
			title={qtip ? null : closeAriaLabel ? closeAriaLabel : tip} 
			disabled={disabled} 
			
			// Click 
			onClick={e => {
				if(disabled){
					e.preventDefault();
					return;
				}
				if(onClick) onClick(e);
			}} 
		/>
	);
}

Btn.defaultProps = {
	As: 'button',
  kind: 'secondary'
};
/* Btn.propTypes = {
  active: P.bool,
  'aria-label': P.string,
  block: P.bool,
  kind: P.string,
  disabled: P.bool,
  outline: P.bool,
  // as: tagPropType,
  inRef: P.oneOfType([P.object, P.func, P.string]),
  onClick: P.func,
  size: P.string,
  children: P.node,
  className: P.string,
  cssModule: P.object,
  close: P.bool
}; */


