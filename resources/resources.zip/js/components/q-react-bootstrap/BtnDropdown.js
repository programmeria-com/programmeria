import React from 'react';
// import PropTypes from 'prop-types';
import Dropdown from './Dropdown';

// const propTypes = {
  // children: PropTypes.node,
// };

const BtnDropdown = (props) => {
  return <Dropdown group {...props} />;
};

// BtnDropdown.propTypes = propTypes;

export default BtnDropdown;
