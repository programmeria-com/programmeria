import React from 'react';
// import P from 'prop-types';
// import Cls from 'classnames';
import {Cx} from '../utils/Q';
import { Transition } from 'react-transition-group';
import { mapToCssModules, omit, pick, TransitionTimeouts, TransitionPropTypeKeys, TransitionStatuses } from './utils';// tagPropType

const transitionStatusToClassHash = {
  [TransitionStatuses.ENTERING]: 'collapsing',
  [TransitionStatuses.ENTERED]: 'collapse show',
  [TransitionStatuses.EXITING]: 'collapsing',
  [TransitionStatuses.EXITED]: 'collapse'
};

function getTransitionClass(status){
  return transitionStatusToClassHash[status] || 'collapse';
}

function getHeight(node){
  return node.scrollHeight;
}

export default class Collapse extends React.Component{
  constructor(props){
    super(props);

    this.state = {
      height: null
    };

    ['onEntering', 'onEntered', 'onExit', 'onExiting', 'onExited'].forEach(name => {
      this[name] = this[name].bind(this);
    });
  }

  onEntering(node, isAppearing){
    this.setState({ height: getHeight(node) });
    this.props.onEntering(node, isAppearing);
  }

  onEntered(node, isAppearing){
    this.setState({ height: null });
    this.props.onEntered(node, isAppearing);
  }

  onExit(node){
    this.setState({ height: getHeight(node) });
    this.props.onExit(node);
  }

  onExiting(node){
    // getting this variable triggers a reflow
    const _unused = node.offsetHeight; // eslint-disable-line no-unused-vars
    this.setState({ height: 0 });
    this.props.onExiting(node);
  }

  onExited(node){
    this.setState({ height: null });
    this.props.onExited(node);
  }

  render(){
    const {As, isOpen, className, navbar, cssModule, children, inRef, ...etc} = this.props;

    const { height } = this.state;

    const transitionProps = pick(etc, TransitionPropTypeKeys);
    const childProps = omit(etc, TransitionPropTypeKeys);
    return (
      <Transition
        {...transitionProps}
        in={isOpen}
        onEntering={this.onEntering}
        onEntered={this.onEntered}
        onExit={this.onExit}
        onExiting={this.onExiting}
        onExited={this.onExited}
      >
        {(status) => {
          let collapseClass = getTransitionClass(status);
          const setCx = mapToCssModules(Cx(
            collapseClass,
            navbar && 'navbar-collapse', className
          ), cssModule);
          
					const style = height === null ? null : { height };
          
					return (
            <As 
              {...childProps}
              style={{...childProps.style, ...style}}
              className={setCx}
              ref={this.props.inRef}
              aria-expanded={isOpen ? 'true' : 'false'}
            >
              {children}
            </As>
          );
        }}
      </Transition>
    );
  }
}

Collapse.defaultProps = {
  ...Transition.defaultProps,
  isOpen: false,
  appear: false,
  enter: true,
  exit: true,
  As: 'div',
  timeout: TransitionTimeouts.Collapse
};
// Collapse.propTypes = {
  // ...Transition.propTypes,
  // isOpen: P.bool,
  // children: P.oneOfType([
    // P.arrayOf(P.node),
    // P.node
  // ]),
  // As: tagPropType,
  // className: P.node,
  // navbar: P.bool,
  // cssModule: P.object,
  // inRef: P.oneOfType([P.func, P.string, P.object])
// };



