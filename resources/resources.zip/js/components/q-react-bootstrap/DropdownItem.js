import React from 'react';
// import PropTypes from 'prop-types';
// import Cls from 'classnames';
import {Cx} from '../utils/Q';
import { DropdownContext } from './DropdownContext';
import { mapToCssModules, omit } from './utils';// tagPropType

// const propTypes = {
  // children: PropTypes.node,
  // active: PropTypes.bool,
  // disabled: PropTypes.bool,
  // divider: PropTypes.bool,
  // as: tagPropType,
  // header: PropTypes.bool,
  // onClick: PropTypes.func,
  // className: PropTypes.string,
  // cssModule: PropTypes.object,
  // toggle: PropTypes.bool
// };

class DropdownItem extends React.Component{
  onClick = (e) => {
    if(this.props.disabled || this.props.header || this.props.divider){
      e.preventDefault();
      return;
    }

    if(this.props.onClick){
      this.props.onClick(e);
    }

    if(this.props.toggle){
      this.context.toggle(e);
    }
  }

  getTabIndex = () => {
    if(this.props.disabled || this.props.header || this.props.divider){
      return '-1';
    }
    return '0';
  }

  render(){
    const tabIndex = this.getTabIndex();
    const role = tabIndex > -1 ? 'menuitem' : undefined;
    let {className, cssModule, divider, as: As, header, active, ...props} = omit(this.props, ['toggle']);

		// classNames
    const setCls = mapToCssModules(Cx(
      {
        disabled: props.disabled,
        'dropdown-item': !divider && !header,
        active: active,
        'dropdown-header': header,
        'dropdown-divider': divider
      }, className
    ), cssModule);

    if(As === 'button'){
      if(header){
        As = 'h6';
      }else if (divider){
        As = 'div';
      }else if (props.href){
        As = 'a';
      }
    }

    return (
      <As
        type={(As === 'button' && (props.onClick || this.props.toggle)) ? 'button' : undefined}
        {...props}
        tabIndex={tabIndex}
        role={role}
        className={setCls}
        onClick={this.onClick}
      />
    );
  }
}

// DropdownItem.propTypes = propTypes;
DropdownItem.defaultProps = {
  as: 'button',
  toggle: true
};
DropdownItem.contextType = DropdownContext;

export default DropdownItem;
