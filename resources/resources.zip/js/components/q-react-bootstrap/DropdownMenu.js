import React from 'react';
// import P from 'prop-types';
// import Cls from 'classnames';
import {Cx} from '../utils/Q';
import { Popper } from 'react-popper';
import { DropdownContext } from './DropdownContext';
import { mapToCssModules } from './utils';// tagPropType

// const propTypes = {
  // As: tagPropType,
  // children: P.node.isRequired,
  // right: P.bool,
  // flip: P.bool,
  // modifiers: P.object,
  // className: P.string,
  // cssModule: P.object,
  // persist: P.bool,
  // positionFixed: P.bool
// };

const noFlipModifier = { flip: { enabled: false } };

const directionPositionMap = {
  up: 'top',
  left: 'left',
  right: 'right',
  down: 'bottom'
};

class DropdownMenu extends React.Component{
  render(){
    const {className, cssModule, right, As, flip, modifiers, persist, positionFixed, ...etc} = this.props;
    // classNames
		const setCx = mapToCssModules(Cx(
      'dropdown-menu',
      {
        'dropdown-menu-right': right,
        show: this.context.isOpen,
      }, className
    ), cssModule);

    const El = As;

    if(persist || (this.context.isOpen && !this.context.inNavbar)){
      const position1 = directionPositionMap[this.context.direction] || 'bottom';
      const position2 = right ? 'end' : 'start';
      const poperPlacement = `${position1}-${position2}`;
      const poperModifiers = !flip ? {
        ...modifiers,
        ...noFlipModifier,
      } : modifiers;
      const popperPositionFixed = !!positionFixed;

      return (
        <Popper
          placement={poperPlacement}
          modifiers={poperModifiers}
          positionFixed={popperPositionFixed}
        >
          {({ ref, style, placement }) => (
            <El
              tabIndex="-1"
              role="menu"
              ref={ref}
              style={style}
              {...etc}
              aria-hidden={!this.context.isOpen}
              className={setCx}
              x-placement={placement}
            />
          )}
        </Popper>
      );
    }

    return (
      <El
        tabIndex="-1"
        role="menu"
        {...etc}
        aria-hidden={!this.context.isOpen}
        className={setCx}
        x-placement={etc.placement}
      />
    );
  }
};

// DropdownMenu.propTypes = propTypes;
DropdownMenu.defaultProps = {
  As: 'div',
  flip: true
};
DropdownMenu.contextType = DropdownContext;

export default DropdownMenu;
