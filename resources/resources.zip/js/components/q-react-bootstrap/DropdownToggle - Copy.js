import React from 'react';
// import P from 'prop-types';
import Cls from 'classnames';
import { Reference } from 'react-popper';
import { DropdownContext } from './DropdownContext';
import { mapToCssModules } from './utils';// tagPropType
import Btn from './Btn'; // Button

class DropdownToggle extends React.Component{
  onClick = (e) => {
		const {disabled, nav, as, onClick} = this.props;
    if(disabled || this.context.disabled){
      e.preventDefault();
      return;
    }

    if(nav && !as){
      e.preventDefault();
    }

    if(onClick) onClick(e);

    this.context.toggle(e);
  }

  render(){
    const {className, kind, caret, split, nav, as, ...props} = this.props; // cssModule
    // const ariaLabel = props['aria-label'] || 'Toggle Dropdown';
		const ariaLabel = !props.children && !props['aria-label'] ? 'Toggle Dropdown' : props['aria-label'];
    
		// classNames
		const setCls = mapToCssModules(Cls(
      {
        'dropdown-toggle': caret || split,
        'dropdown-toggle-split': split,
        'nav-link': nav
      }, className
    )); // , cssModule
    
		// const children = props.children || <span className="sr-only">{ariaLabel}</span>;

    let As;

    if(nav && !as){
      // As = 'a';
      // props.href = '#';
			As = 'span';
			props.tabIndex = "0";
			props.role = "button";
    }
		else if(!as){ // 
      As = Btn;
      props.kind = kind;
      // props.cssModule = cssModule;
    }else{
      As = as;
    }

    if(this.context.inNavbar){
      return (
        <As
          {...props}
          className={setCls}
          onClick={this.onClick}
          aria-expanded={this.context.isOpen}
          // children={children}
					aria-label={ariaLabel}
        />
      );
    }

    return (
      <Reference>
        {({ ref }) => (
          <As
            {...props}
            // {...{ [typeof As === 'string' ? 'ref' : 'innerRef']: ref }}
            {...{ [typeof As === 'string' ? 'ref' : 'inRef']: ref }}
						
            className={setCls}
            onClick={this.onClick}
            aria-expanded={this.context.isOpen}
            // children={children}
						aria-label={ariaLabel}
          />
        )}
      </Reference>
    );
  }
}

// DropdownToggle.propTypes = propTypes;
DropdownToggle.defaultProps = {
  'aria-haspopup': true,
  kind: 'secondary'
};

// const propTypes = {
  // caret: P.bool,
  // color: P.string,
  // children: P.node,
  // className: P.string,
  // cssModule: P.object,
  // disabled: P.bool,
  // onClick: P.func,
  // 'aria-haspopup': P.bool,
  // split: P.bool,
  // as: tagPropType,
  // nav: P.bool
// };

DropdownToggle.contextType = DropdownContext;

export default DropdownToggle;
