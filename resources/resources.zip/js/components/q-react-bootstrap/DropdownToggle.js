import React from 'react';
// import P from 'prop-types';
// import {Cls} from '../../utils';// classnames
import {Cx} from '../utils/Q';
import { Reference } from 'react-popper';
import { DropdownContext } from './DropdownContext';
import { mapToCssModules } from './utils';// tagPropType
import Btn from './Btn'; // Button

class DropdownToggle extends React.Component{
  onClick = (e) => {
		const {disabled, nav, As, onClick, toggleContextMenu} = this.props;
    if(disabled || this.context.disabled || toggleContextMenu){
      e.preventDefault();
			
			if(onClick){
				if(this.context.isOpen) this.context.toggle(e);
				onClick(e);// Q-CUSTOM
			}
			
      return;
    }

    if(nav && !As) e.preventDefault();

    if(onClick) onClick(e);

    this.context.toggle(e);
  }
	
// Q-CUSTOM
	onContextMenu = (e, isCtx) => {
		if(isCtx){
			e.preventDefault();
			this.context.toggle(e);
			
			const {onContextMenu} = this.props;
			if(onContextMenu) onContextMenu(e);
		}
	}

  render(){
    const {className, cssModule, kind, caret, split, nav, As, toggleContextMenu, ...props} = this.props;
    // const ariaLabel = props['aria-label'] || 'Toggle Dropdown';
		const ariaLabel = !props.children && !props['aria-label'] ? 'Toggle Dropdown' : props['aria-label'];
		const setCx = mapToCssModules(Cx(
      {
        'dropdown-toggle': caret || split,
        'dropdown-toggle-split': split,
        'nav-link': nav
      }, className
    ), cssModule);
    
		// const children = props.children || <span className="sr-only">{ariaLabel}</span>;

    let El;

    if(nav && !As){
      // As = 'a';
      // props.href = '#';
			El = 'span';
			props.tabIndex = "0";
			props.role = "button";
    }
		else if(!As){ // 
      El = Btn;
      props.kind = kind;
      // props.cssModule = cssModule;
    }else{
      El = As;
    }

    if(this.context.inNavbar){
      return (
        <El
          {...props}
          className={setCx}
          onClick={this.onClick} 
					onContextMenu={e => this.onContextMenu(e, toggleContextMenu)} // Q-CUSTOM
          aria-expanded={this.context.isOpen} 
          // children={children}
					aria-label={ariaLabel}
        />
      );
    }

    return (
      <Reference>
        {({ ref }) => (
          <El
            {...props}
            // {...{ [typeof El === 'string' ? 'ref' : 'innerRef']: ref }}
            {...{ [typeof El === 'string' ? 'ref' : 'inRef']: ref }}
						
            className={setCx}
            onClick={this.onClick} 
						onContextMenu={e => this.onContextMenu(e, toggleContextMenu)} // Q-CUSTOM
            aria-expanded={this.context.isOpen}
            // children={children}
						aria-label={ariaLabel}
          />
        )}
      </Reference>
    );
  }
}

// DropdownToggle.propTypes = propTypes;
DropdownToggle.defaultProps = {
  'aria-haspopup': true,
  kind: 'secondary',
	// toggleContextMenu: false
};

// const propTypes = {
  // caret: P.bool,
  // color: P.string,
  // children: P.node,
  // className: P.string,
  // cssModule: P.object,
  // disabled: P.bool,
  // onClick: P.func,
  // 'aria-haspopup': P.bool,
  // split: P.bool,
  // as: tagPropType,
  // nav: P.bool
// };

DropdownToggle.contextType = DropdownContext;

export default DropdownToggle;
