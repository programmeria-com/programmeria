import React from 'react';
import P from 'prop-types';
// import classNames from 'classnames';
import {Cx} from '../utils/Q';
import { Transition } from 'react-transition-group';
import { mapToCssModules, omit, pick, TransitionPropTypeKeys, TransitionTimeouts, tagPropType } from './utils';

// console.log(Transition.propTypes);

const timeoutsShape = P.oneOfType([P.number, P.shape({
	enter: P.number,
	exit: P.number,
	appear: P.number
}).isRequired]);

const FADE_PROP_TYPES = { // propTypes
	// ORI 
  // ...Transition.propTypes,
	
	// Q-CUSTOM
	// FROM Transition = react-transition-group :
	in: P.bool,
	mountOnEnter: P.bool,
	unmountOnExit: P.bool,
	appear: P.bool,
	enter: P.bool,
	exit: P.bool,
  timeout: function timeout(props){
    let pt = timeoutsShape;
    if(!props.addEndListener) pt = pt.isRequired;

		let args;
    for(let _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
      args[_key - 1] = arguments[_key];
    }

    return pt.apply(void 0, [props].concat(args));
  },
	addEndListener: P.func,
	onEnter: P.func,
	onEntering: P.func,
	onEntered: P.func,
	onExit: P.func,
	onExiting: P.func,
	onExited: P.func,
	
  children: P.oneOfType([
    P.arrayOf(P.node),
    P.node
  ]),
  As: tagPropType,
  baseClass: P.string,
  baseClassActive: P.string,
  className: P.string,
  cssModule: P.object,
  inRef: P.oneOfType([P.object, P.string, P.func])
};

const defaultProps = {
  ...Transition.defaultProps,
	
  As: 'div',
  baseClass: 'fade',
  baseClassActive: 'show',
  timeout: TransitionTimeouts.Fade,
  appear: true,
  enter: true,
  exit: true,
  in: true
};

function Fade({As, baseClass, baseClassActive, className, cssModule, children, inRef, ...etc}){
  const transitionProps = pick(etc, TransitionPropTypeKeys);
  const childProps = omit(etc, TransitionPropTypeKeys);

  return (
    <Transition {...transitionProps}>
      {(status) => {
        const isActive = status === 'entered';
        const classes = mapToCssModules(Cx(
          className,
          baseClass,
          isActive && baseClassActive
        ), cssModule);
        return (
          <As className={classes} {...childProps} ref={inRef}>
            {children}
          </As>
        );
      }}
    </Transition>
  );
}

// Q-CUSTOM
P.checkPropTypes(Fade, FADE_PROP_TYPES, 'FADE_PROP_TYPES', 'Fade');

// ORI 
// Fade.propTypes = FADE_PROP_TYPES;

Fade.defaultProps = defaultProps;

export {FADE_PROP_TYPES};
export default Fade;
