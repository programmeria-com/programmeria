import React from 'react';
import P from 'prop-types';
import Cls from 'classnames';
import { mapToCssModules } from './utils';// tagPropType

const InputGroup = ({className, cssModule, as: As, size, ...etc}) => {
  const setCls = mapToCssModules(Cls(
    'input-group',
    size ? `input-group-${size}` : null,
		className
  ), cssModule);

  return <As {...etc} className={setCls} />;
};

InputGroup.propTypes = {
  // as: tagPropType,
  size: P.string,
  className: P.string,
  cssModule: P.object
};
InputGroup.defaultProps = {
  as: 'div'
};

export default InputGroup;
