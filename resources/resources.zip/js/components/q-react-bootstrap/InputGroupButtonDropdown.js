import React from 'react';
import P from 'prop-types';
import Dropdown from './Dropdown';

const InputGroupButtonDropdown = props => {
  return <Dropdown {...props} />;
};

InputGroupButtonDropdown.propTypes = {
  addonType: P.oneOf(['prepend', 'append']).isRequired,
  children: P.node
};

export default InputGroupButtonDropdown;
