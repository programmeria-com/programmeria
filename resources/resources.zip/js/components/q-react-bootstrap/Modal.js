import React from 'react';
import P from 'prop-types';
// import Cls from 'classnames';
import {Cx} from '../utils/Q';
import Portal from './Portal';
import Fade, {FADE_PROP_TYPES} from './Fade';
import {getOriginalBodyPadding, conditionallyUpdateScrollbar, setScrollbarWidth, mapToCssModules, omit, 
				focusableElements, TransitionTimeouts} from './utils';

function noop(){}

const FadePropTypes = P.shape(FADE_PROP_TYPES);// ORI = P.shape(Fade.propTypes);

const propTypes = {
  isOpen: P.bool,
  autoFocus: P.bool,
  centered: P.bool,
  scrollable: P.bool,
  size: P.string,
  toggle: P.func,
  keyboard: P.bool,
  role: P.string,
  labelledBy: P.string,
  backdrop: P.oneOfType([P.bool, P.oneOf(['static'])]),
  onEnter: P.func,
  onExit: P.func,
  onOpened: P.func,
  onClosed: P.func,
  children: P.node,
  className: P.string,
  wrapClassName: P.string,
  modalClassName: P.string,
  backdropClassName: P.string,
  contentClassName: P.string,
  external: P.node,
  fade: P.bool,
  cssModule: P.object,
  zIndex: P.oneOfType([P.number, P.string]),
  backdropTransition: FadePropTypes,
  modalTransition: FadePropTypes,
  inRef: P.oneOfType([P.object, P.string, P.func]),
  unmountOnClose: P.bool,
  returnFocusAfterClose: P.bool
};

const propsToOmit = Object.keys(propTypes);

export default class Modal extends React.Component{
  constructor(props){
    super(props);

    this._element = null;
    this._originalBodyPadding = null;
    this.getFocusableChildren = this.getFocusableChildren.bind(this);
    this.handleBackdropClick = this.handleBackdropClick.bind(this);
    this.handleBackdropMouseDown = this.handleBackdropMouseDown.bind(this);
    this.handleEscape = this.handleEscape.bind(this);
    this.handleTab = this.handleTab.bind(this);
    this.onOpened = this.onOpened.bind(this);
    this.onClosed = this.onClosed.bind(this);
    this.manageFocusAfterClose = this.manageFocusAfterClose.bind(this);

    this.state = {
      isOpen: false
    };
  }

  componentDidMount(){
    const {isOpen, autoFocus, onEnter} = this.props;

    if(isOpen){
      this.init();
      this.setState({isOpen: true});
			
      if(autoFocus){
        this.setFocus();
      }
    }

    if(onEnter){
      onEnter();
    }

    this._isMounted = true;
  }

  componentDidUpdate(prevProps, prevState){
    if(this.props.isOpen && !prevProps.isOpen){
      this.init();
      this.setState({isOpen: true});
      // let render() renders Modal Dialog first
      return;
    }

    // now Modal Dialog is rendered and we can refer this._element and this._dialog
    if(this.props.autoFocus && this.state.isOpen && !prevState.isOpen){
      this.setFocus();
    }

    if(this._element && prevProps.zIndex !== this.props.zIndex){
      this._element.style.zIndex = this.props.zIndex;
    }
  }

  componentWillUnmount(){
    if(this.props.onExit){
      this.props.onExit();
    }

    if(this._element){
      this.destroy();
      if(this.state.isOpen){
        this.close();
      }
    }

    this._isMounted = false;
  }

  onOpened(node, isAppearing){
    this.props.onOpened();
    (this.props.modalTransition.onEntered || noop)(node, isAppearing);
  }

  onClosed(node){
    const {unmountOnClose} = this.props;
    // so all methods get called before it is unmounted
    this.props.onClosed();
    (this.props.modalTransition.onExited || noop)(node);

    if(unmountOnClose){
      this.destroy();
    }
    this.close();

    if(this._isMounted){
      this.setState({isOpen: false});
    }
  }

  setFocus(){
    if(this._dialog && this._dialog.parentNode && typeof this._dialog.parentNode.focus === 'function'){
      this._dialog.parentNode.focus();
    }
  }

  getFocusableChildren(){
    return this._element.querySelectorAll(focusableElements.join(', '));
  }

  getFocusedChild(){
    let currentFocus;
    const focusableChildren = this.getFocusableChildren();

    try{
      currentFocus = document.activeElement;
    }catch(err){
      currentFocus = focusableChildren[0];
    }
    return currentFocus;
  }

  // not mouseUp because scrollbar fires it, shouldn't close when user scrolls
  handleBackdropClick(e){
    if(e.target === this._mouseDownElement){
      e.stopPropagation();
      if(!this.props.isOpen || this.props.backdrop !== true) return;

      const backdrop = this._dialog ? this._dialog.parentNode : null;

      if(backdrop && e.target === backdrop && this.props.toggle){
        this.props.toggle(e);
      }
    }
  }

  handleTab(e){
    if(e.which !== 9) return;

    const focusableChildren = this.getFocusableChildren();
    const totalFocusable = focusableChildren.length;
		
    if(totalFocusable === 0) return;
    const currentFocus = this.getFocusedChild();

    let focusedIndex = 0;

    for(let i = 0; i < totalFocusable; i += 1){
      if(focusableChildren[i] === currentFocus){
        focusedIndex = i;
        break;
      }
    }

    if(e.shiftKey && focusedIndex === 0){
      e.preventDefault();
      focusableChildren[totalFocusable - 1].focus();
    }else if(!e.shiftKey && focusedIndex === totalFocusable - 1){
      e.preventDefault();
      focusableChildren[0].focus();
    }
  }

  handleBackdropMouseDown(e){
    this._mouseDownElement = e.target;
  }

  handleEscape(e){
    if(this.props.isOpen && this.props.keyboard && e.keyCode === 27 && this.props.toggle){
      e.preventDefault();
      e.stopPropagation();
      this.props.toggle(e);
    }
  }

  init(){
    try{
      this._triggeringElement = document.activeElement;
    }catch(err){
      this._triggeringElement = null;
    }

    if(!this._element){
      this._element = document.createElement('div');
      this._element.setAttribute('tabindex', '-1');
      this._element.style.position = 'relative';
      this._element.style.zIndex = this.props.zIndex;
      document.body.appendChild(this._element);
    }

    this._originalBodyPadding = getOriginalBodyPadding();
    conditionallyUpdateScrollbar();

    if(Modal.openCount === 0){
      document.body.className = Cx(
        document.body.className,
        mapToCssModules('modal-open', this.props.cssModule)
      );
    }

    Modal.openCount += 1;
  }

  destroy(){
    if(this._element){
      document.body.removeChild(this._element);
      this._element = null;
    }

    this.manageFocusAfterClose();
  }

  manageFocusAfterClose(){
    if(this._triggeringElement){
      const {returnFocusAfterClose} = this.props;
      
			if(this._triggeringElement.focus && returnFocusAfterClose) this._triggeringElement.focus();
      this._triggeringElement = null;
    }
  }

  close(){
    if(Modal.openCount <= 1){
      const modalOpenClassName = mapToCssModules('modal-open', this.props.cssModule);
      // Use regex to prevent matching `modal-open` as part of a different class, e.g. `my-modal-opened`
      const modalOpenClassNameRegex = new RegExp(`(^| )${modalOpenClassName}( |$)`);
      document.body.className = document.body.className.replace(modalOpenClassNameRegex, ' ').trim();
    }
    this.manageFocusAfterClose();
    Modal.openCount = Math.max(0, Modal.openCount - 1);

    setScrollbarWidth(this._originalBodyPadding);
  }

  renderModalDialog(){
    const attributes = omit(this.props, propsToOmit);
    const dialogBaseClass = 'modal-dialog';

    return (
      <div
        {...attributes}
        className={mapToCssModules(Cx(dialogBaseClass, {
          [`modal-${this.props.size}`]: this.props.size,
          [`${dialogBaseClass}-centered`]: this.props.centered,
          [`${dialogBaseClass}-scrollable`]: this.props.scrollable,
        }), this.props.className, this.props.cssModule)}
        role="document"
        ref={(c) => {
          this._dialog = c;
        }}
      >
        <div
          className={mapToCssModules(
            Cx('modal-content', this.props.contentClassName),
            this.props.cssModule
          )}
        >
          {this.props.children}
        </div>
      </div>
    );
  }

  render(){
    const {unmountOnClose} = this.props;

    if(!!this._element && (this.state.isOpen || !unmountOnClose)){
      const isModalHidden = !!this._element && !this.state.isOpen && !unmountOnClose;
      this._element.style.display = isModalHidden ? 'none' : 'block';

      const {wrapClassName, modalClassName, backdropClassName, cssModule, isOpen, backdrop, role, labelledBy, external, inRef} = this.props;

      const modalAttributes = {
        onClick: this.handleBackdropClick,
        onMouseDown: this.handleBackdropMouseDown,
        onKeyUp: this.handleEscape,
        onKeyDown: this.handleTab,
        style: { display: 'block' },
        'aria-labelledby': labelledBy,
        role,
        tabIndex: '-1'
      };

      const hasTransition = this.props.fade;
      const modalTransition = {
        ...Fade.defaultProps,
        ...this.props.modalTransition,
        baseClass: hasTransition ? this.props.modalTransition.baseClass : '',
        timeout: hasTransition ? this.props.modalTransition.timeout : 0,
      };
      const backdropTransition = {
        ...Fade.defaultProps,
        ...this.props.backdropTransition,
        baseClass: hasTransition ? this.props.backdropTransition.baseClass : '',
        timeout: hasTransition ? this.props.backdropTransition.timeout : 0,
      };

      const Backdrop = backdrop && (
        hasTransition ?
          (<Fade
            {...backdropTransition}
            in={isOpen && !!backdrop}
            cssModule={cssModule}
            className={mapToCssModules(Cx('modal-backdrop', backdropClassName), cssModule)}
          />)
          : <div className={mapToCssModules(Cx('modal-backdrop', 'show', backdropClassName), cssModule)} />
      );

      return (
        <Portal node={this._element}>
          <div className={mapToCssModules(wrapClassName)}>
            <Fade
              {...modalAttributes}
              {...modalTransition}
              in={isOpen}
              onEntered={this.onOpened}
              onExited={this.onClosed}
              cssModule={cssModule}
              className={mapToCssModules(Cx('modal', modalClassName), cssModule)}
              inRef={inRef}
            >
              {external}
              {this.renderModalDialog()}
            </Fade>
						
            {Backdrop}
          </div>
        </Portal>
      );
    }
    return null;
  }
}

// ORI 
// Modal.propTypes = propTypes;

// Q-CUSTOM
P.checkPropTypes(Modal, propTypes, 'propTypes', 'Modal');

Modal.defaultProps = {
  isOpen: false,
  autoFocus: true,
  centered: false,
  scrollable: false,
  role: 'dialog',
  backdrop: true,
  keyboard: true,
  zIndex: 1050,
  fade: true,
  onOpened: noop,
  onClosed: noop,
  modalTransition: {
    timeout: TransitionTimeouts.Modal
  },
  backdropTransition: {
    mountOnEnter: true,
    timeout: TransitionTimeouts.Fade // uses standard fade transition
  },
  unmountOnClose: true,
  returnFocusAfterClose: true
};
Modal.openCount = 0;

// export default Modal;
