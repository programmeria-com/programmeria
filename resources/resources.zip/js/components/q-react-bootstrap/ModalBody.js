import React from 'react';
import P from 'prop-types';
import Cls from 'classnames';
import {mapToCssModules, tagPropType} from './utils';

const ModalBody = ({className, cssModule, as: As, ...etc}) => {
  const setCls = mapToCssModules(Cls(
    'modal-body', className
  ), cssModule);

  return (
    <As {...etc} className={setCls} />
  );
};

ModalBody.propTypes = {
  tag: tagPropType,
  className: P.string,
  cssModule: P.object
};
ModalBody.defaultProps = {
  as: 'div'
};

export default ModalBody;
