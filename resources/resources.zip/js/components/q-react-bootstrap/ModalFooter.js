import React from 'react';
import P from 'prop-types';
import Cls from 'classnames';
import {mapToCssModules, tagPropType} from './utils';

const ModalFooter = ({className, cssModule, as: As,...etc}) => {  
	const setCls = mapToCssModules(Cls(
    'modal-footer', className
  ), cssModule);

  return (
    <As {...etc} className={setCls} />
  );
};

ModalFooter.propTypes = {
  as: tagPropType,
  className: P.string,
  cssModule: P.object
};
ModalFooter.defaultProps = {
  as: 'div'
};

export default ModalFooter;
