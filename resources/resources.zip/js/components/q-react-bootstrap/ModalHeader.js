import React from 'react';
// import P from 'prop-types';
// import Cls from 'classnames';
import {Cx} from '../utils/Q';
import {mapToCssModules} from './utils';// tagPropType

export default function ModalHeader({className, cssModule, children, modalTitle, toggle, As, wrapAs: WrapAs, closeAriaLabel, charCode, close, titleClass, ...etc}){
  let closeButton;

  const setCx = mapToCssModules(Cx(
    'modal-header', className
  ), cssModule);

  if(!close && toggle){
    const closeIcon = typeof charCode === 'number' ? String.fromCharCode(charCode) : charCode;
    closeButton = (
      <button type="button" onClick={toggle} className={mapToCssModules('close', cssModule)} aria-label={closeAriaLabel}>
        <span aria-hidden="true">{closeIcon}</span>
      </button>
    );
  }

  return (
    <WrapAs {...etc} className={setCx}>
      <As className={mapToCssModules(Cx('modal-title', titleClass), cssModule)}>
        {modalTitle} 
      </As>
			
			{children}
			
      {close || closeButton}
    </WrapAs>
  );
};

ModalHeader.defaultProps = {
  As: 'h5',
  wrapAs: 'div',
  closeAriaLabel: 'Close',
  charCode: 215
};
// ModalHeader.propTypes = {
  // As: tagPropType,
  // wrapAs: tagPropType,
  // toggle: P.func,
  // className: P.string,
  // cssModule: P.object,
  // children: P.node,
  // closeAriaLabel: P.string,
  // charCode: P.oneOfType([P.string, P.number]),
  // close: P.object
// };
