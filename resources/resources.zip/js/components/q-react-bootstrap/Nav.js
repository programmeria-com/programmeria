import React from 'react';
// import P from 'prop-types';
// import Cls from 'classnames';
import {Cx} from '../utils/Q';
import { mapToCssModules } from './utils';// tagPropType

const getVerticalClass = (v) => {
  if(v === false){
    return false;
  }else if(v === true || v === 'xs'){
    return 'flex-column';
  }
  return `flex-${v}-column`;
};

export default function Nav({className, cssModule, tabs, pills, vertical, horizontal, justified, fill, navbar, card, As, ...etc}){
  const setCx = mapToCssModules(Cx(
    navbar ? 'navbar-nav' : 'nav',
    horizontal ? `justify-content-${horizontal}` : false,
    getVerticalClass(vertical),
    {
      'nav-tabs': tabs,
      'card-header-tabs': card && tabs,
      'nav-pills': pills,
      'card-header-pills': card && pills,
      'nav-justified': justified,
      'nav-fill': fill,
    }, className
  ), cssModule);

  return (
    <As {...etc} className={setCx} />
  );
};

Nav.defaultProps = {
  As: 'ul',
  vertical: false
};
// Nav.propTypes = {
  // tabs: P.bool,
  // pills: P.bool,
  // vertical: P.oneOfType([P.bool, P.string]),
  // horizontal: P.string,
  // justified: P.bool,
  // fill: P.bool,
  // navbar: P.bool,
  // card: P.bool,
  // As: tagPropType,
  // className: P.string,
  // cssModule: P.object
// };

