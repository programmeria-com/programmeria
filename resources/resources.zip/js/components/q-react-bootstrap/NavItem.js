import React from 'react';
// import P from 'prop-types';
// import Cls from 'classnames';
import {Cx} from '../utils/Q';
import { mapToCssModules } from './utils';// tagPropType

export default function NavItem({className, cssModule, active, As, ...etc}){
  const setCx = mapToCssModules(Cx(
    'nav-item',
    active ? 'active' : false,
		className
  ), cssModule);

  return (
    <As {...etc} className={setCx} />
  );
};

NavItem.defaultProps = {
  As: 'li'
};
// NavItem.propTypes = {
  // as: tagPropType,
  // active: P.bool,
  // className: P.string,
  // cssModule: P.object
// };
