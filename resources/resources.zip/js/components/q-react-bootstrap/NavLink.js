import React from 'react';
// import P from 'prop-types';
// import Cls from 'classnames';
import {Cx} from '../utils/Q';
import { mapToCssModules } from './utils';// tagPropType

export default function NavLink({className, cssModule, active, As, inRef, href, disabled, onClick, ...etc}){
  const Click = e => {
    if(disabled){
      e.preventDefault();
      return;
    }

    if(href === '#' || !href){
      e.preventDefault();
    }

    if(onClick) onClick(e);
  }

	const setCx = mapToCssModules(Cx(
		'nav-link',
		{
			disabled: disabled, // etc.disabled
			active: active
		}, className
	), cssModule);

	return <As {...etc} ref={inRef} href={href} onClick={Click} className={setCx} tabIndex={!href || As !== 'a' ? '0':null} />;
}

NavLink.defaultProps = {
  As: 'a'
};
// NavLink.propTypes = {
  // As: tagPropType,
  // inRef: P.oneOfType([P.object, P.func, P.string]),
  // disabled: P.bool,
  // active: P.bool,
  // className: P.string,
  // cssModule: P.object,
  // onClick: P.func,
  // href: P.any
// };


