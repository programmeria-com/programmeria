import React from 'react';
// import P from 'prop-types';
// import Cls from 'classnames';
import {Cx} from '../utils/Q';
import { mapToCssModules } from './utils';// tagPropType

const getExpandClass = (exp) => {
  if(exp === false){
    return false;
  }else if(exp === true || exp === 'xs'){
    return 'navbar-expand';
  }
  return `navbar-expand-${exp}`;
};

export default function Navbar({expand, className, cssModule, light, dark, fixed, sticky, kind, As, ...etc}){
  const setCx = mapToCssModules(Cx(
    'navbar',
    getExpandClass(expand),
    {
      'navbar-light': light,
      'navbar-dark': dark,
      [`bg-${kind}`]: kind,
      [`fixed-${fixed}`]: fixed,
      [`sticky-${sticky}`]: sticky,
    }, className
  ), cssModule);

  return <As {...etc} className={setCx} />;
};

Navbar.defaultProps = {
  As: 'nav',
  expand: false
};
// Navbar.propTypes = {
  // light: P.bool,
  // dark: P.bool,
  // full: P.bool,
  // fixed: P.string,
  // sticky: P.string,
  // kind: P.string,
  // role: P.string,
  // As: tagPropType,
  // className: P.string,
  // cssModule: P.object,
  // expand: P.oneOfType([P.bool, P.string])
// };

