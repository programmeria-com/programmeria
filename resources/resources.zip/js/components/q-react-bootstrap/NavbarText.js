import React from 'react';
// import P from 'prop-types';
// import Cls from 'classnames';
import {Cx} from '../utils/Q';
import { mapToCssModules } from './utils';// tagPropType

export default function NavbarText({className, cssModule, active, As, ...etc}){
  const setCx = mapToCssModules(Cx(
    'navbar-text', className
  ), cssModule);

  return <As {...etc} className={setCx} />;
};

NavbarText.defaultProps = {
  As: 'span'
};
// NavbarText.propTypes = {
  // As: tagPropType,
  // className: P.string,
  // cssModule: P.object
// };
