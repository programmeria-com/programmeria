import React from 'react';
// import P from 'prop-types';
// import Cls from 'classnames';
import {Cx} from '../utils/Q';
import { mapToCssModules } from './utils';// tagPropType

export default function NavbarToggler({className, cssModule, children, As, ...etc}){
  const setCx = mapToCssModules(Cx(
    'navbar-toggler', className
  ), cssModule);

  return (
    <As aria-label="Toggle navigation" {...etc} className={setCx}>
      {children || <span className={mapToCssModules('navbar-toggler-icon', cssModule)} />}
    </As>
  );
};

NavbarToggler.defaultProps = {
  As: 'button',
  type: 'button'
};
// NavbarToggler.propTypes = {
  // As: tagPropType,
  // type: P.string,
  // className: P.string,
  // cssModule: P.object,
  // children: P.node
// };
