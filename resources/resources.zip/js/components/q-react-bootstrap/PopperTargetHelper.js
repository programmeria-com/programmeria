// import P from 'prop-types';
import { getTarget } from './utils';// targetPropType

export default function PopperTargetHelper(props, context){
  context.popperManager.setTargetNode(getTarget(props.target));
  return null;
};

PopperTargetHelper.contextTypes = {
  popperManager: P.object.isRequired
};

// PopperTargetHelper.propTypes = {
  // target: targetPropType.isRequired
// };
