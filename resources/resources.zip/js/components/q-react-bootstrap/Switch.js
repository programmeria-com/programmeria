import React from 'react';
import Cls from 'classnames';
// import Btn from '../../components/reactstrap/Btn';

export default function Switch({as: As, className, id, label, ...etc}){
  // const [data, setData] = React.useState();
	
	// React.useEffect(() => {
		// console.log('%cuseEffect in Switch','color:yellow;');
	// }, []);

	return (
		<As className={Cls("custom-control custom-switch", className)}>
			<input {...etc} type="checkbox" className="custom-control-input" id={id} />
			
			{
				React.createElement(As === 'label' ? 'div' : 'label', {
					className: "custom-control-label",
					htmlFor: As !== 'label' ? id : undefined
				}, label)
			}
		</As>
	);
}
// <label className="custom-control-label" htmlFor={id}>{label}</label>

Switch.defaultProps = {
	as: 'label'
};

/*
		<React.Fragment>
			
		</React.Fragment>
*/
