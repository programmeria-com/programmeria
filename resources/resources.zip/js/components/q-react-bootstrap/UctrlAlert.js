import React from 'react';
import Alert from './Alert';

export default function UctrlAlert(props){
	const [open, setOpen] = React.useState(true);

  return <Alert isOpen={open} toggle={() => setOpen(!open)} {...props} />;
}


