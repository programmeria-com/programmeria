import React from 'react';// , { Component }
// import P from 'prop-types';
import BtnDropdown from './BtnDropdown';// ButtonDropdown
import { omit } from './utils';

export default function UctrlBtnDropdown(props){ // defaultOpen, onToggle, ...etc
	const [open, setOpen] = React.useState(props.defaultOpen || false);

  return (
		<BtnDropdown  
			isOpen={open} 
			toggle={e => {
				setOpen(!open);
				if(props.onToggle) props.onToggle(e, !open);
			}} 
			{...omit(props, ['defaultOpen'])} 
		/>
	);
}

// UctrlBtnDropdown.propTypes = {
  // defaultOpen: P.bool,
  // ...BtnDropdown.propTypes
// };
