import React from 'react';// , { Component }
// import P from 'prop-types';
import Dropdown from './Dropdown';
import { omit } from './utils';

// const omitKeys = ['defaultOpen'];

export default function UctrlDropdown(props){ // defaultOpen, onToggle, ...etc
	const [open, setOpen] = React.useState(props.defaultOpen || false);

  return (
		<Dropdown 
			isOpen={open} 
			toggle={e => {
				setOpen(!open);
				if(props.onToggle) props.onToggle(e, !open);
			}} 
			{...omit(props, ['defaultOpen'])} // omitKeys
		/>
	);
}

// UncontrolledDropdown.propTypes = {
  // defaultOpen: P.bool,
  // onToggle: P.func,
  // ...Dropdown.propTypes
// };
