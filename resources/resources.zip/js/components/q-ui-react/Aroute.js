import React from 'react';
// import Cls from 'classnames';
import {NavLink} from 'react-router-dom';
import {Cx, hasClass, hasAttr, isFunc} from '../utils/Q';
// import Btn from '../../components/reactstrap/Btn';

// ref, strict, 
export default function Aroute({
	nav, btn, size, outline, dropdown, className, disabled, onClick, onContextMenu, 
	tip, qtip, role, children, ...etc
}){
  // const [data, setData] = React.useState();
	// const refA = React.createRef();
	// const getRef = ref || refA;

	const CtxMenu = e => {
		if(disabled){
			e.preventDefault();
			return;
		}
		if(isFunc(onContextMenu)) onContextMenu(e);
	}

/* 	React.useEffect(() => {
		console.log('%cuseEffect in Aroute','color:yellow;');
		console.log(getRef.current);

		if(getRef && disabled){
			getRef.current.addEventListener('auxclick', CtxMenu, false);
		}

		// return () => {
			// if(getRef && disabled){
				// getRef.current.removeEventListener('auxclick', CtxMenu, false);
			// }
		// }

	}, [getRef, disabled, CtxMenu]); */

	const Click = e => {
		let et = e.target;

    if(disabled){
      e.preventDefault();
      return;
    }
		// console.log(hasAttr(et, 'aria-current'));
    if(hasClass(et, "dropdown-item")) document.body.click();
		
		// let isActive = hasClass(et, "active") || hasAttr(et, 'aria-current');
		// console.log(isActive);
		// console.log("active", hasClass(et, "active"));
		// console.log('aria-current', hasAttr(et, 'aria-current'));
		
    if(hasClass(et, "active") || hasAttr(et, 'aria-current')){ // aria-expanded="true" | aria-current
			e.preventDefault();
			e.stopPropagation();
			return;
		}

    if(isFunc(onClick)) onClick(e);// custom click to props
	}

	return (
		<NavLink
			{...etc}
			// strict={strict} 
			// ref={ref ? ref : refA}
			onClick={Click}
			onContextMenu={CtxMenu}

			className={
				Cx(`${btn ? 'btn btn':''}${outline ? '-outline' : ''}${btn ? '-'+btn : ''}`, {
					'nav-link' : nav,
					// [`btn btn-${btn}`] : btn,
					[`btn-${size}`] : btn && size,

					'dropdown-item' : dropdown,
					[`tip tip${qtip}`] : qtip,
					'disabled' : disabled
				}, className)
			}
			role={btn ? 'button' : role}
			title={qtip ? null : tip}
			aria-label={(!children || typeof children === 'undefined' || qtip) && tip ? tip : null}
			tabIndex={disabled ? "-1" : null}
			aria-disabled={disabled ? true : null} 
			// data-api={api} // FOR link with api
		>
			{children}
		</NavLink>
	);
}

// Aroute.defaultProps = {
	// btn: false
// };

/*

*/
