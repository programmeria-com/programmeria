import React from 'react';

/** Loops React Component with render props & auto key 
@usage: 
	<Loops 
		data={chartSetting.xAxis}
	>
		{(v, i) => (
			<li>{v.xaxisname} <Btn kind="danger" size="xs" onClick={() => this.onChartRemove('xAxis', i, v)}>X</Btn></li>
		)}
	</Loops> */

const Loops = ({data = [], children}) => React.Children.toArray(data.map((v, i) => children && children(v, i)));
export default Loops;
