// ====== Utilities ======
// import cx from 'classnames';

// classnames extends
// const Cls = (v) => cx.apply(null, ...v) || undefined;
// function Cls(){
  // return cx.apply(null, arguments) || undefined;
// }

// === Type checking ===
function isStr(v){
	return typeof v === 'string' || v instanceof String;
}

function isArr(v){
	return v && typeof v === 'object' && v instanceof Array;// v.constructor === Array
}

function isObj(v){
	return v && typeof v === 'object' && v.constructor === Object;
}

function isFunc(v){
	return v && typeof v === 'function';
}

// Q classnames
function Cx(){
  let hasOwn = {}.hasOwnProperty,
			c = [],
			alength = arguments.length;

  for(let i = 0; i < alength; i++){
		let arg = arguments[i];
		if(!arg) continue;

		// let argType = typeof arg;

		if(isStr(arg) || typeof arg === 'number'){ // argType === 'string' || argType === 'number'
			c.push(arg);
		}else if(isArr(arg) && arg.length){ // Array.isArray(arg) && arg.length
			let inr = Cx.apply(null, arg);
			if(inr) c.push(inr); // inner
		}else if(isObj(arg)){ // argType === 'object'
			for(let k in arg){
				if(hasOwn.call(arg, k) && arg[k]) c.push(k);
			}
		}
  }
  return c.length > 0 ? c.join(' ') : undefined;
}

/** FROM: blueprint.js utils - Safely invoke the function with the given arguments, if it is indeed a
 * function, and return its value. Otherwise, return undefined */
function safeInvoke(fn, ...args){
	if(isFunc(fn)){
		return fn(...args);
	}
	return undefined;
}
// === END Type checking ===

// == dom-q.js ===
// let DOC = document;
function domQ(q, dom = document){
  return dom.querySelector(q);
}

function domQall(q, dom = document){
  return dom.querySelectorAll(q);
}

/** USAGE:
	add = setClass(element, "btn active");
	remove = setClass(element, "btn active", 'remove'); */
function setClass(el, c, fn = 'add'){
  let cls = c.split(" ");
  el.classList[fn](...cls);
}

function toggleClass(el, c, cek){
  el.classList.toggle(c, cek);
}

function replaceClass(el, o, n){
  hasClass(el, o) ? el.classList.replace(o, n) : el.classList.replace(n, o);
}

function hasClass(el, c){
  return el.classList.contains(c);
}

function hasAttr(el, a){
  return el.hasAttribute(a);
}

function getAttr(el, a){
  return el.getAttribute(a);
}

/**
	@el : Element / node
	@attr : attribute name & value (Object)
*/
function setAttr(el, attr){ // del
	if(el){
		if(isObj(attr)) Object.entries(attr).forEach(v => el.setAttribute(v[0], v[1]));
		else if(isStr(attr)) attr.split(" ").forEach(v => el.removeAttribute(v));
		else console.warn('setAttr() : params 2 required Object to add / string to remove, To remove several attributes, separate the attribute names with a space.');
	}
	else{
		console.warn('setAttr() : params 1 required DOM');
	}
}
// === END dom-q.js ===

// Prevent Default
function noop(e){
  e.preventDefault();
  e.stopPropagation();
}

/** Bind multiple component methods:
	* @param {this} context
	* @param {Array} functions
	constructor(){
		...
		bindFuncs.call(this,['onClick','onModal']);
	}
*/
function bindFuncs(fns){
	fns.forEach(f => (this[f] = this[f].bind(this)));
}


/** add / remove EventListener
	{
		@to = target to bind event | default = document
		@listen = add / remove event | default = 'add'
		@type 	= event type name, e.g 'click','keyup' etc (required)
		@fn 		= function in EventListener (required)
	}
*/
// function toggleEvent({
	// to = document,
	// listen = 'add',
	// type,
	// fn
// } = {}){
	// to[listen + 'EventListener'](type, fn);
// }

// function isSupportLocaleDateString(date){
  // try {
    // date.toLocaleDateString('i');// new Date().toLocaleDateString('i');
  // }catch(e){
    // return e.name === 'RangeError';
  // }
  // return false;
// }

function isValidLang(lang){
	if(!window.Intl) return;
	try {
		let supportLocOf = Intl.DateTimeFormat.supportedLocalesOf(lang, {localeMatcher:'lookup'});// lookup | best fit
		let isOk = supportLocOf && Intl.getCanonicalLocales(lang) ? supportLocOf.length : false;
		return isOk;
	}catch(e){
		console.warn(e.message);// expected output: RangeError: invalid language tag: lang
	}
}

function dateIntl(dt, options, lang = 'en'){
	if(!dt || !isValidLang(lang)) return;// && !isSupportLocaleDateString(dt)

	// console.log('isValidLang: ',!isValidLang(lang));
	try {
		let setOptions = {
			weekday:'long', // long | short | narrow
			year:'numeric', // numeric | 2-digit
			month:'long', // numeric | 2-digit | long | short | narrow
			day:'numeric', // numeric | 2-digit
			// hour: '', // numeric | 2-digit
			// minute: '', // numeric | 2-digit
			// second: '', // numeric | 2-digit
			...options
		};
		// console.log(setOptions);

		return new Intl.DateTimeFormat(lang, setOptions).format(dt);
	}catch(e){
		console.warn(e.message);
	}
}

// DEV ONLY:
/* function dummyArray(space = ' ', lng){
	// const str = () => Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
	let str = `Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat Duis aute irure dolor in reprehenderit in voluptate velit esse
cillum dolore eu fugiat nulla pariatur Excepteur sint occaecat cupidatat non
proident sunt in culpa qui officia deserunt mollit anim id est laborum`;

	if(Number.isInteger(lng) && lng > 0) return Array.from({length: lng}, (v, k) => v + space + (k + 1));
	else return Array.from(str.split(" "), (v, k) => v + space + (k + 1));
} */

export {
	Cx, isStr, isArr, isObj, isFunc, safeInvoke,
	domQ, domQall, setClass, toggleClass, replaceClass, hasClass,
	hasAttr, getAttr, setAttr,
	noop, bindFuncs,
	isValidLang, dateIntl, // dateLocale,
	// toggleEvent,
	// dummyArray,
};

/* FROM ContentEditable.js */
/* function normalizeHtml(str){
  return str && str.replace(/&nbsp;|\u202F|\u00A0/g, ' ');
}
function replaceCaret(el){
  // Place the caret at the end of the element
  let target = document.createTextNode('');
  el.appendChild(target);
  // do not move caret if element was not focused
  let isTargetFocused = document.activeElement === el;
  if(target !== null && target.nodeValue !== null && isTargetFocused){
    let sel = window.getSelection();
    if(sel !== null){
      let range = document.createRange();
      range.setStart(target, target.nodeValue.length);
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
    }
    if(el instanceof HTMLElement) el.focus();
  }
} */

// FOR check mobile device
/* function isMobile(){
  return !!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
} */

/* function dateToStr(dt){
	let date = new Date(dt);
	return date.toDateString();
} */

/** Check html tagName **/
/* function isTag(t){ // tagCheck
	// let c = document.createElement(t),
			// b = c.toString() !== "[object HTMLUnknownElement]"
  // return {valid:b, el:c};
	return document.createElement(t).toString() !== "[object HTMLUnknownElement]";
} */

/* function winOpen(e, url, name){
	if(e) e.preventDefault();
	let left = (window.screen.width - 550) / 2;// (screen.width - myWidth) / 2;
	let top = (window.screen.height - 350) / 2;
	return window.open(url, name,'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,copyhistory=no,width=550,height=350,top='+top+',left='+left);
} */

// === FROM reactstrap ===
// function getScrollbarWidth(){
//   let scrollDiv = document.createElement('div');
//   // .modal-scrollbar-measure styles // https://github.com/twbs/bootstrap/blob/v4.0.0-alpha.4/scss/_modal.scss#L106-L113
//   scrollDiv.style.position = 'absolute';
//   scrollDiv.style.top = '-9999px';
//   scrollDiv.style.width = '50px';
//   scrollDiv.style.height = '50px';
//   scrollDiv.style.overflow = 'scroll';
//   document.body.appendChild(scrollDiv);
//   let scrollbarWidth = scrollDiv.offsetWidth - scrollDiv.clientWidth;
//   document.body.removeChild(scrollDiv);
//   return scrollbarWidth;
// }

// function setScrollbarWidth(padding){
//   document.body.style.paddingRight = padding > 0 ? `${padding}px` : null;
// }

// function isBodyOverflowing(){
//   return document.body.clientWidth < window.innerWidth;
// }

// function getOriginalBodyPadding(){
//   let style = window.getComputedStyle(document.body, null);
//   return parseInt((style && style.getPropertyValue('padding-right')) || 0, 10);
// }

// function conditionallyUpdateScrollbar(){
//   let scrollbarWidth = getScrollbarWidth();
//   // https://github.com/twbs/bootstrap/blob/v4.0.0-alpha.6/js/src/modal.js#L433
//   let fixedContent = document.querySelectorAll(
//     '.fixed-top, .fixed-bottom, .is-fixed, .sticky-top'
//   )[0];
//   let bodyPadding = fixedContent ? parseInt(fixedContent.style.paddingRight || 0, 10) : 0;

//   if(isBodyOverflowing()){
//     setScrollbarWidth(bodyPadding + scrollbarWidth);
//   }
// }

// /* Returns a new object with the key/value pairs from `obj` that are not in the array `omitKeys` */
// function omit(obj, omitKeys){
//   let result = {};
//   Object.keys(obj).forEach(key => {
//     if(omitKeys.indexOf(key) === -1){
//       result[key] = obj[key];
//     }
//   });
//   return result;
// }

// /* Returns a filtered copy of an object with only the specified keys */
// function pick(obj, keys){
//   let pickKeys = Array.isArray(keys) ? keys : [keys],
//       length = pickKeys.length,
//       key,
//       result = {};

//   while(length > 0){
//     length -= 1;
//     key = pickKeys[length];
//     result[key] = obj[key];
//   }
//   return result;
// }
// === END FROM reactstrap ===
