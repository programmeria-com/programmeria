import {useState, useEffect, useLayoutEffect} from 'react';

const useStateCb = (iState, cb) => {
  const [state, setState] = useState(iState);

  useEffect(() => cb(state), [state, cb]);

  return [state, setState];
};

const useStateCbInstant = (iState, cb) => {
  const [state, setState] = useState(iState);

  useLayoutEffect(() => cb(state), [state, cb]);

  return [state, setState];
};

export {useStateCbInstant}; // useStateCallbackInstant

export default useStateCb; // useStateCallback
