<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no">
<meta name="description" content="Programmer sharing">
<meta name="author" content="Programmeria">
<meta name="mobile-web-app-capable" content="yes">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="theme-color" content="#ffffff">
<meta name="_token" content="{{ csrf_token() }}">
<link rel="shortcut icon" href="/favicon.ico">
<title>Programmeria</title>
{{-- <link rel="preload" href="/css/app.css" as="style" type="text/css" crossorigin="anonymous"> --}}
<link rel="stylesheet" href="/css/app.css" crossorigin="anonymous">
<link rel="stylesheet" href="/admin/css/admin-ui.css" crossorigin="anonymous">
<style>

</style>
</head>
<body>
<div id="root"></div>

<script>document.documentElement.classList.add('js')</script>
<script src="/js/app.js"></script>
<script>

</script>
</body></html>
